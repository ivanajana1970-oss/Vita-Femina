# Femina Vita – probni sajt ginekološke ordinacije

Statični sajt (HTML + CSS + malo JavaScript-a), spreman za GitHub Pages.

- `index.html` – početna stranica
- `zakazivanje.html` – zakazivanje pregleda i utisci
- `images/` – fotografije i mapa

## Objavljivanje na GitHub Pages
1. Napravite novi repozitorijum na GitHub-u (npr. `femina-vita`).
2. Otpremite sve fajlove iz ovog foldera (Add file › Upload files) u koren repozitorijuma.
3. Settings › Pages › Source: „Deploy from a branch“, grana `main`, folder `/ (root)` › Save.
4. Posle minut-dva sajt je na `https://<korisničko-ime>.github.io/femina-vita/`.

Napomena: formulari su demonstracioni – podaci se nigde ne šalju.
